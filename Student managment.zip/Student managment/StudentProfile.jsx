import { useState } from "react";

function StudentProfile({ students }) {
  const [id, setId] = useState("");
  const student = students.find((s) => s.stdid === id);

  return (
    <div>
      <h2>View Student Profile</h2>
      <input placeholder="Enter Student ID" value={id} onChange={(e) => setId(e.target.value)} />
      {student ? (
        <div>
          <p>Name: {student.stdname}</p>
          <p>Standard: {student.standard}</p>
          <p>Age: {student.age}</p>
          <p>Roll: {student.roll}</p>
        </div>
      ) : (
        id && <p>No student found</p>
      )}
    </div>
  );
}
export default StudentProfile
