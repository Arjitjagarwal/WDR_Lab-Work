import StudentRegistration from "./StudentRegistration";
import StutList from "./StuList"
import DeleteStudent from "./DeleteStudent";
import StudentProfile from "./StudentProfile"
import UpdateStudent from "./UpdateStudent";

function App() {
  
  return (
    <div>
      <h1>Student Management App</h1>
      <StudentRegistration />
      <StutList />
      <DeleteStudent/>
      <StudentProfile/>
      <UpdateStudent/>
    </div>
  );
}

export default App;