import { useState } from "react";

function UpdateStudent({ students, updateStudent }) {
  const [id, setId] = useState("");
  const [standard, setStandard] = useState("");
  const [roll, setRoll] = useState("");

  return (
    <div>
      <h2>Update Student</h2>

      <input placeholder="Enter ID" onChange={(e) => setId(e.target.value)} />

      <input
        placeholder="New Standard"
        onChange={(e) => setStandard(e.target.value)}
      />

      <input
        placeholder="New Roll"
        onChange={(e) => setRoll(e.target.value)}
      />

      <button onClick={() =>
        updateStudent(parseInt(id), { standard, roll })
      }>
        Update
      </button>
    </div>
  );
}

export default UpdateStudent;