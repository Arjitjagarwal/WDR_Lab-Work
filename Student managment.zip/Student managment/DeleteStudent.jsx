import { useState } from "react";

function DeleteStudent({ students, deleteStudent }) {
  const [id, setId] = useState("");

  return (
    <div>
      <h2>Delete Student</h2>
      <input
        placeholder="Enter Student ID"
        onChange={(e) => setId(e.target.value)}
      />
      <button onClick={() => deleteStudent(parseInt(id))}>
        Delete
      </button>
    </div>
  );
}

export default DeleteStudent;