function StuList({ students }) {
  return (
    <div>
      <h2>All Students</h2>
      {students.length === 0 ? (
        <p>No students registered</p>
      ) : (
        <ul>
          {students.map((s) => (
            <li key={s.stdid}>
              {s.stdname} — Std: {s.standard}, Roll: {s.roll}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default StuList
