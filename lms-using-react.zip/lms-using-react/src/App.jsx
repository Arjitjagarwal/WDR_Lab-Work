import { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";

import "../src/index.css";
import CourseNavigationBar from "./coursemanagement/CourseNavigationBar";
import CourseRegistration from "./coursemanagement/CourseRegistration";
import CourseUpdate from "./coursemanagement/CourseUpdate";
import CourseDelete from "./coursemanagement/CourseDelete";
import CourseList from "./coursemanagement/CourseList";
import CourseDetails from "./coursemanagement/CourseDetails";

function App() {
  // main array to store courses
  const [courses, setCourses] = useState([
    // optional sample to test quickly
    // {
    //   courseid: "C101",
    //   coursename: "Intro to React",
    //   description: "React basics",
    //   duration: 20,
    //   min_enroll: 5,
    //   max_enroll: 50,
    //   created_at: "2025-11-17"
    // }
  ]);

  return (
    <BrowserRouter>
      <div className="container">
        <div className="header">
          <h1>LMS — Course Management</h1>
        </div>

        <CourseNavigationBar />

        <div style={{ marginTop: 14 }}>
          <Routes>
            <Route path="/" element={<Navigate to="/course/register" replace />} />
            <Route path="/course/register" element={<CourseRegistration courses={courses} setCourses={setCourses} />} />
            <Route path="/course/update" element={<CourseUpdate courses={courses} setCourses={setCourses} />} />
            <Route path="/course/delete" element={<CourseDelete courses={courses} setCourses={setCourses} />} />
            <Route path="/course/list" element={<CourseList courses={courses} />} />
            <Route path="/course/details" element={<CourseDetails courses={courses} />} />
            {/* fallback - redirect */}
            <Route path="*" element={<Navigate to="/course/list" replace />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
