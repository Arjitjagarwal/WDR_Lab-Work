import { useForm } from "react-hook-form";

/**
 * CourseRegistration
 * - Adds a course object to `courses` array
 * - Uses react-hook-form (useForm)
 */
function CourseRegistration({ courses, setCourses }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  function onSubmit(data) {
    // Basic validation: min_enroll should be <= max_enroll
    const minE = Number(data.min_enroll);
    const maxE = Number(data.max_enroll);

    if (!data.courseid.trim() || !data.coursename.trim()) {
      alert("Course ID and Course Name are required.");
      return;
    }

    if (minE > maxE) {
      alert("Min enrollment cannot be greater than Max enrollment.");
      return;
    }

    // Save course object (all fields are strings from form except numbers)
    const courseObj = {
      ...data,
      duration: Number(data.duration || 0),
      min_enroll: Number(data.min_enroll || 0),
      max_enroll: Number(data.max_enroll || 0),
    };

    setCourses([...courses, courseObj]);
    alert("✅ Course Registered");
    reset();
  }

  return (
    <div className="card">
      <h2>Course Registration</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="form-row">
          <div className="input-group">
            <label>Course ID *</label>
            <input {...register("courseid", { required: true, maxLength: 30 })} />
            {errors.courseid && <span className="small-muted">Required (max 30 chars)</span>}
          </div>

          <div className="input-group">
            <label>Course Name *</label>
            <input {...register("coursename", { required: true, maxLength: 300 })} />
            {errors.coursename && <span className="small-muted">Required (max 300 chars)</span>}
          </div>

          <div className="input-group">
            <label>Description</label>
            <textarea {...register("description", { maxLength: 400 })} />
          </div>

          <div className="input-group">
            <label>Duration (hours)</label>
            <input type="number" {...register("duration", { min: 0 })} />
          </div>

          <div className="input-group">
            <label>Min Enrollment</label>
            <input type="number" {...register("min_enroll", { min: 0 })} />
          </div>

          <div className="input-group">
            <label>Max Enrollment</label>
            <input type="number" {...register("max_enroll", { min: 0 })} />
          </div>

          <div className="input-group">
            <label>Created / Updated Date</label>
            <input type="date" {...register("created_at")} />
          </div>
        </div>

        <div style={{ marginTop: 12 }}>
          <button type="submit">Register Course</button>
          <span className="note"> &nbsp;* required fields</span>
        </div>
      </form>
    </div>
  );
}

export default CourseRegistration;
