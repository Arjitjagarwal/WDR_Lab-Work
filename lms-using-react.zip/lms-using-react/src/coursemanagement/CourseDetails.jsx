import { useForm } from "react-hook-form";
import { useState } from "react";

/**
 * CourseDetails
 * - Enter courseid and show details
 */
function CourseDetails({ courses }) {
  const { register, handleSubmit } = useForm();
  const [selected, setSelected] = useState(null);

  function onSubmit(values) {
    const id = values.courseid?.trim();
    if (!id) return alert("Enter Course ID");
    const found = courses.find((c) => c.courseid === id);
    if (!found) {
      setSelected(null);
      alert("Course not found");
      return;
    }
    setSelected(found);
  }

  return (
    <div className="card">
      <h2>Course Details</h2>

      <form onSubmit={handleSubmit(onSubmit)} style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="Enter Course ID" {...register("courseid")} />
          <button type="submit" className="ghost">Get Details</button>
        </div>
      </form>

      {selected ? (
        <div style={{ marginTop: 12 }}>
          <div className="course-item">
            <div>
              <div><strong>{selected.courseid} — {selected.coursename}</strong></div>
              <div className="course-meta">{selected.description}</div>
              <div className="small-muted">Duration: {selected.duration} hrs</div>
              <div className="small-muted">Enroll: {selected.min_enroll} to {selected.max_enroll}</div>
              <div className="small-muted">Date: {selected.created_at}</div>
            </div>
          </div>
        </div>
      ) : <div className="note">Enter a Course ID to view details.</div>}
    </div>
  );
}

export default CourseDetails;
