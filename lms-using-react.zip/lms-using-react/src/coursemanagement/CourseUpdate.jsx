import { useForm } from "react-hook-form";
import { useState } from "react";

/**
 * CourseUpdate
 * - Provide courseid to pick course, then update fields you fill (non-empty)
 */
function CourseUpdate({ courses, setCourses }) {
  const { register, handleSubmit, reset } = useForm();
  const [found, setFound] = useState(null);

  // find by id
  function handleFind(values) {
    const id = values.courseid?.trim();
    if (!id) return alert("Enter Course ID to find.");
    const c = courses.find((x) => x.courseid === id);
    if (!c) {
      alert("Course not found.");
      setFound(null);
      return;
    }
    setFound(c);
  }

  // update (only fields filled in update form will be applied)
  function handleUpdate(values) {
    if (!found) return alert("First find a course by Course ID.");
    const updated = { ...found };

    // apply only fields that are present and not empty
    if (values.coursename) updated.coursename = values.coursename;
    if (values.description) updated.description = values.description;
    if (values.duration) updated.duration = Number(values.duration);
    if (values.min_enroll) updated.min_enroll = Number(values.min_enroll);
    if (values.max_enroll) updated.max_enroll = Number(values.max_enroll);
    if (values.created_at) updated.created_at = values.created_at;

    const newList = courses.map((c) => (c.courseid === updated.courseid ? updated : c));
    setCourses(newList);
    alert("✅ Course updated");
    setFound(updated);
    reset();
  }

  return (
    <div className="card">
      <h2>Update Course</h2>

      <form onSubmit={handleSubmit(handleFind)}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input placeholder="Enter Course ID to find" {...register("courseid")} />
          <button type="submit" className="ghost">Find</button>
        </div>
      </form>

      {found ? (
        <div style={{ marginTop: 12 }}>
          <div className="small-muted">Editing: <strong>{found.courseid}</strong> — {found.coursename}</div>

          <form onSubmit={handleSubmit(handleUpdate)} style={{ marginTop: 12 }}>
            <div className="form-row">
              <div className="input-group">
                <label>New Course Name</label>
                <input {...register("coursename")} placeholder={found.coursename} />
              </div>

              <div className="input-group">
                <label>New Description</label>
                <input {...register("description")} placeholder={found.description} />
              </div>

              <div className="input-group">
                <label>Duration (hours)</label>
                <input type="number" {...register("duration")} placeholder={found.duration} />
              </div>

              <div className="input-group">
                <label>Min Enrollment</label>
                <input type="number" {...register("min_enroll")} placeholder={found.min_enroll} />
              </div>

              <div className="input-group">
                <label>Max Enrollment</label>
                <input type="number" {...register("max_enroll")} placeholder={found.max_enroll} />
              </div>

              <div className="input-group">
                <label>Updated Date</label>
                <input type="date" {...register("created_at")} />
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <button type="submit">Apply Update</button>
            </div>
          </form>
        </div>
      ) : (
        <div className="note" style={{ marginTop: 12 }}>
          Enter Course ID and click <strong>Find</strong> to load course data here.
        </div>
      )}
    </div>
  );
}

export default CourseUpdate;
