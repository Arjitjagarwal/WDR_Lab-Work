/**
 * CourseList
 * - Shows all courses stored in array
 */
function CourseList({ courses }) {
  return (
    <div className="card">
      <h2>All Courses</h2>

      {courses.length === 0 ? (
        <div className="note">No courses found. Add courses via Registration.</div>
      ) : (
        courses.map((c) => (
          <div key={c.courseid} className="course-item">
            <div>
              <div><strong>{c.courseid} — {c.coursename}</strong></div>
              <div className="course-meta">{c.description}</div>
              <div className="small-muted">Duration: {c.duration} hrs • Min: {c.min_enroll} • Max: {c.max_enroll}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div className="small-muted">{c.created_at}</div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default CourseList;
