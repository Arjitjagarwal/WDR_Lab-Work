import { Link } from "react-router-dom";

function CourseNavigationBar() {
  return (
    <nav className="navbar card">
      <Link className="nav-link" to="/course/register">Course Registration</Link>
      <Link className="nav-link" to="/course/update">Course Update</Link>
      <Link className="nav-link" to="/course/delete">Course Delete</Link>
      <Link className="nav-link" to="/course/list">Course List</Link>
      <Link className="nav-link" to="/course/details">Course Details</Link>
    </nav>
  );
}

export default CourseNavigationBar;
