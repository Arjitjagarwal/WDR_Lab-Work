import { useForm } from "react-hook-form";
import { useState } from "react";

/**
 * CourseDelete
 * - Enter course id, find and delete
 */
function CourseDelete({ courses, setCourses }) {
  const { register, handleSubmit } = useForm();
  const [found, setFound] = useState(null);

  function handleFind(values) {
    const id = values.courseid?.trim();
    if (!id) return alert("Enter ID to find.");
    const c = courses.find((x) => x.courseid === id);
    if (!c) {
      alert("Course not found.");
      setFound(null);
      return;
    }
    setFound(c);
  }

  function handleDelete() {
    if (!found) return;
    const filtered = courses.filter((c) => c.courseid !== found.courseid);
    setCourses(filtered);
    setFound(null);
    alert("✅ Course deleted");
  }

  return (
    <div className="card">
      <h2>Delete Course</h2>

      <form onSubmit={handleSubmit(handleFind)} style={{ marginBottom: 12 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <input placeholder="Course ID to delete" {...register("courseid")} />
          <button type="submit" className="ghost">Find</button>
        </div>
      </form>

      {found ? (
        <div>
          <div className="course-item" style={{ alignItems: "flex-start" }}>
            <div>
              <div><strong>{found.courseid} — {found.coursename}</strong></div>
              <div className="course-meta">{found.description}</div>
            </div>
            <div className="actions">
              <button className="btn-danger" onClick={handleDelete}>Delete</button>
            </div>
          </div>
        </div>
      ) : (
        <div className="note">Find a course first to delete it.</div>
      )}
    </div>
  );
}

export default CourseDelete;
