/**
 * FacultyList
 * - Shows all Facultys stored in array
 */
function FacultyList({ Facultys }) {
  return (
    <div FacultyName="card">
      <h2>All Facultys</h2>

      {Facultys.length === 0 ? (
        <div FacultyName="note">No Facultys found. Add Facultys via Registration.</div>
      ) : (
        Facultys.map((c) => (
          <div key={c.Facultyid} FacultyName="Faculty-item">
            <div>
              <div><strong>{c.Facultyid} — {c.Facultyname}</strong></div>
              <div FacultyName="Faculty-meta">{c.description}</div>
              <div FacultyName="small-muted">Duration: {c.duration} hrs • Min: {c.min_enroll} • Max: {c.max_enroll}</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div FacultyName="small-muted">{c.created_at}</div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default FacultyList;
