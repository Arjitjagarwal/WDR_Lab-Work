import { useForm } from "react-hook-form";

/**
 * FacultyRegistration
 * - Adds a Faculty object to `Facultys` array
 * - Uses react-hook-form (useForm)
 */
function FacultyRegistration({ Facultys, setFacultys }) {
  const { register, handleSubmit, reset, formState: { errors } } = useForm();

  function onSubmit(data) {
    // Basic validation: min_enroll should be <= max_enroll
    const minE = Number(data.min_enroll);
    const maxE = Number(data.max_enroll);

    if (!data.Facultyid.trim() || !data.Facultyname.trim()) {
      alert("Faculty ID and Faculty Name are required.");
      return;
    }

    if (minE > maxE) {
      alert("Min enrollment cannot be greater than Max enrollment.");
      return;
    }

    // Save Faculty object (all fields are strings from form except numbers)
    const FacultyObj = {
      ...data,
      duration: Number(data.duration || 0),
      min_enroll: Number(data.min_enroll || 0),
      max_enroll: Number(data.max_enroll || 0),
    };

    setFacultys([...Facultys, FacultyObj]);
    alert("✅ Faculty Registered");
    reset();
  }

  return (
    <div FacultyName="card">
      <h2>Faculty Registration</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div FacultyName="form-row">
          <div FacultyName="input-group">
            <label>Faculty ID *</label>
            <input {...register("Facultyid", { required: true, maxLength: 30 })} />
            {errors.Facultyid && <span FacultyName="small-muted">Required (max 30 chars)</span>}
          </div>

          <div FacultyName="input-group">
            <label>Faculty Name *</label>
            <input {...register("Facultyname", { required: true, maxLength: 300 })} />
            {errors.Facultyname && <span FacultyName="small-muted">Required (max 300 chars)</span>}
          </div>

          <div FacultyName="input-group">
            <label>Description</label>
            <textarea {...register("description", { maxLength: 400 })} />
          </div>

          <div FacultyName="input-group">
            <label>Duration (hours)</label>
            <input type="number" {...register("duration", { min: 0 })} />
          </div>

          <div FacultyName="input-group">
            <label>Min Enrollment</label>
            <input type="number" {...register("min_enroll", { min: 0 })} />
          </div>

          <div FacultyName="input-group">
            <label>Max Enrollment</label>
            <input type="number" {...register("max_enroll", { min: 0 })} />
          </div>

          <div FacultyName="input-group">
            <label>Created / Updated Date</label>
            <input type="date" {...register("created_at")} />
          </div>
        </div>

        <div style={{ marginTop: 12 }}>
          <button type="submit">Register Faculty</button>
          <span FacultyName="note"> &nbsp;* required fields</span>
        </div>
      </form>
    </div>
  );
}

export default FacultyRegistration;
