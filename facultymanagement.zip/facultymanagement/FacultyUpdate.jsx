import { useForm } from "react-hook-form";
import { useState } from "react";

/**
 * FacultyUpdate
 * - Provide Facultyid to pick Faculty, then update fields you fill (non-empty)
 */
function FacultyUpdate({ Facultys, setFacultys }) {
  const { register, handleSubmit, reset } = useForm();
  const [found, setFound] = useState(null);

  // find by id
  function handleFind(values) {
    const id = values.Facultyid?.trim();
    if (!id) return alert("Enter Faculty ID to find.");
    const c = Facultys.find((x) => x.Facultyid === id);
    if (!c) {
      alert("Faculty not found.");
      setFound(null);
      return;
    }
    setFound(c);
  }

  // update (only fields filled in update form will be applied)
  function handleUpdate(values) {
    if (!found) return alert("First find a Faculty by Faculty ID.");
    const updated = { ...found };

    // apply only fields that are present and not empty
    if (values.Facultyname) updated.Facultyname = values.Facultyname;
    if (values.description) updated.description = values.description;
    if (values.duration) updated.duration = Number(values.duration);
    if (values.min_enroll) updated.min_enroll = Number(values.min_enroll);
    if (values.max_enroll) updated.max_enroll = Number(values.max_enroll);
    if (values.created_at) updated.created_at = values.created_at;

    const newList = Facultys.map((c) => (c.Facultyid === updated.Facultyid ? updated : c));
    setFacultys(newList);
    alert("✅ Faculty updated");
    setFound(updated);
    reset();
  }

  return (
    <div FacultyName="card">
      <h2>Update Faculty</h2>

      <form onSubmit={handleSubmit(handleFind)}>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input placeholder="Enter Faculty ID to find" {...register("Facultyid")} />
          <button type="submit" FacultyName="ghost">Find</button>
        </div>
      </form>

      {found ? (
        <div style={{ marginTop: 12 }}>
          <div FacultyName="small-muted">Editing: <strong>{found.Facultyid}</strong> — {found.Facultyname}</div>

          <form onSubmit={handleSubmit(handleUpdate)} style={{ marginTop: 12 }}>
            <div FacultyName="form-row">
              <div FacultyName="input-group">
                <label>New Faculty Name</label>
                <input {...register("Facultyname")} placeholder={found.Facultyname} />
              </div>

              <div FacultyName="input-group">
                <label>New Description</label>
                <input {...register("description")} placeholder={found.description} />
              </div>

              <div FacultyName="input-group">
                <label>Duration (hours)</label>
                <input type="number" {...register("duration")} placeholder={found.duration} />
              </div>

              <div FacultyName="input-group">
                <label>Min Enrollment</label>
                <input type="number" {...register("min_enroll")} placeholder={found.min_enroll} />
              </div>

              <div FacultyName="input-group">
                <label>Max Enrollment</label>
                <input type="number" {...register("max_enroll")} placeholder={found.max_enroll} />
              </div>

              <div FacultyName="input-group">
                <label>Updated Date</label>
                <input type="date" {...register("created_at")} />
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <button type="submit">Apply Update</button>
            </div>
          </form>
        </div>
      ) : (
        <div FacultyName="note" style={{ marginTop: 12 }}>
          Enter Faculty ID and click <strong>Find</strong> to load Faculty data here.
        </div>
      )}
    </div>
  );
}

export default FacultyUpdate;
