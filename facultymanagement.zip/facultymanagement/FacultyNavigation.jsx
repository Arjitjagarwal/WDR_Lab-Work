import { Link } from "react-router-dom";

function FacultyNavigationBar() {
  return (
    <nav FacultyName="navbar card">
      <Link FacultyName="nav-link" to="/Faculty/register">Faculty Registration</Link>
      <Link FacultyName="nav-link" to="/Faculty/update">Faculty Update</Link>
      <Link FacultyName="nav-link" to="/Faculty/list">Faculty List</Link>
      <Link FacultyName="nav-link" to="/Faculty/details">Faculty Details</Link>
    </nav>
  );
}

export default FacultyNavigationBar;
