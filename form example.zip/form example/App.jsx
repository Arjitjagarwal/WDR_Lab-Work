import FormComponent from "./FormComponent"
function App() {


  return (
    
      <div>
<FormComponent></FormComponent>
      </div>

  )
}

export default App
